echo "ido Fastboot Tool Ver 5.0"

fastboot $* getvar product 2>&1 | grep "^product: ido"

if [ $? -ne 0 ] ; then echo "Missmatching image and device"; exit 1; fi
fastboot $* flash aboot `dirname $0`/images/emmc_appsboot.mbn
fastboot $* flash abootbak `dirname $0`/images/emmc_appsboot.mbn

fastboot $* flash recovery `dirname $0`/images/recovery.img

fastboot $* reboot
